package com.example.datapassinactivity;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        onclickbuttontopassdata();
    }


    public void onclickbuttontopassdata()
    {
        Button button=(Button)findViewById(R.id.buttonimplicit);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editText=(EditText)findViewById(R.id.editText);
                String url=editText.getText().toString();

                Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            }
        });



        Button btn=(Button)findViewById(R.id.buttonmain);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EditText tdt=(EditText)findViewById(R.id.editText);

                String datato =tdt.getText().toString();

                Intent intent = new Intent(MainActivity.this,ActivityTwo.class);
                intent.putExtra("datatosend",datato);

                startActivity(intent);

            }
        });

    }

}
