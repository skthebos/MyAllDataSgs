package com.example.datapassinactivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ActivityTwo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity_two);

        String s = getIntent().getStringExtra("datatosend");
        TextView textView=(TextView)findViewById(R.id.textviewsecontactivity);
        textView.setText(s);
    }



}
