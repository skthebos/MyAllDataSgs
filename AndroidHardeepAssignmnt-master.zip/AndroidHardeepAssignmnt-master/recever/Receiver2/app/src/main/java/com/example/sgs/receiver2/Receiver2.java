package com.example.sgs.receiver2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompatSideChannelService;
import android.widget.Switch;
import android.widget.Toast;

/**
 * Created by SGS on 5/11/2017.
 */
public class Receiver2 extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        switch(intent.getAction())
        {
            case Intent.ACTION_POWER_CONNECTED:
            Toast.makeText(context, "Ritu plugged in ", Toast.LENGTH_SHORT).show();
                break;
            case Intent.ACTION_AIRPLANE_MODE_CHANGED:
                Toast.makeText(context, "Aeroplane mode changed", Toast.LENGTH_SHORT).show();
                break;
            case Intent.ACTION_BATTERY_LOW:
                Toast.makeText(context, "charger lga ftaft furrrrrr", Toast.LENGTH_SHORT).show();
                break;
            case Intent.ACTION_SHUTDOWN:
                Toast.makeText(context, "Shutting down", Toast.LENGTH_SHORT).show();
                break;
            case Intent.ACTION_HEADSET_PLUG:
                Toast.makeText(context, "Headset plug", Toast.LENGTH_SHORT).show();
                break;
            case Intent.ACTION_CAMERA_BUTTON:
                Toast.makeText(context, "Camera on Action" , Toast.LENGTH_SHORT).show();
                break;
             default:
            Toast.makeText(context, "plugged out ", Toast.LENGTH_SHORT).show();

        }
    }
}
2gfcv-+