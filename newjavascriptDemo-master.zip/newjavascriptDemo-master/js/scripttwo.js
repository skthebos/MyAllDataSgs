function check_name()//this function is check name validation 
{
	var ck_name =/^[a-zA-Z ]{2,15}$/;
	var name = document.form.name.value;
	if(name.match(ck_name)) //match the pattern with input data
	{
		document.getElementById("nameimg").style.display="initial";
document.getElementById("lbl_name").innerHTML="ok";
		document.getElementById("nameimg").src="images/right.png"; //set right tick image if the name match
		return true; //return true if the pattern match 
	}
	else
	{
		document.getElementById("nameimg").style.display="initial";
		document.getElementById("lbl_name").innerHTML="not ok";
		document.getElementById("nameimg").src="images/wrong.png";////set wrong tick image if the name does not match
		return false; //return false if the pattern does not match
	}
}
function check_number() //this function is check name validation 
{
	var ck_number =/^[0-9]{10,12}$/;
	var mobile = document.form.mobile.value;
	if(mobile.match(ck_number))
	{
		document.getElementById("mobileimg").style.display="initial";
		document.getElementById("mobileimg").src="images/right.png";
		return true;//return true if the pattern match 
	}
	else
	{
		document.getElementById("mobileimg").style.display="initial";
		document.getElementById("mobileimg").src="images/wrong.png";
		return false;//return false if the pattern does not match
	}
}

function check_state() //this function is check state validation 
{
	var continent=document.form.state.value;
	 if (continent == "")
	 {
		document.getElementById("stateimg").style.display="initial";
		document.getElementById("stateimg").src="images/wrong.png";
		return false;//return false if the pattern does not match 
	 }
	 else
	 {
		document.getElementById("stateimg").style.display="initial";
		document.getElementById("stateimg").src="images/right.png";
		return true;//return true if the pattern match 
	 }
}

function check_district() //this function is check state validation 
{
	var d_district=document.form.district.value;
	 if (d_district == "")
	 {
		document.getElementById("districtimges").style.display="initial";
		document.getElementById("districtimges").src="images/wrong.png";
		return false;//return false if the pattern does not match 
	 }
	 else
	 {
			document.getElementById("districtimges").style.display="initial";
		document.getElementById("districtimges").src="images/right.png";
		return true;//return true if the pattern match 
	 }
}
function check_mandal() //this function is check state validation 
{
	var mandal=document.form.mondal.value;
	 if (mandal == "")
	 {
		document.getElementById("mandalimg").style.display="initial";
		document.getElementById("mandalimg").src="images/wrong.png";
		return false;//return false if the pattern does not match 
	 }
	 else
	 {
		document.getElementById("mandalimg").style.display="initial";
		document.getElementById("mandalimg").src="images/right.png";
		return true;//return true if the pattern match 
	 }
}
function check_village() //this function is check state validation 
{
	var village=document.form.village.value;
	 if (village == "")
	 {
		document.getElementById("villageimg").style.display="initial";
		document.getElementById("villageimg").src="images/wrong.png";
		return false;//return false if the pattern does not match 
	 }
	 else
	 {
		document.getElementById("villageimg").style.display="initial";
		document.getElementById("villageimg").src="images/right.png";
		return true;//return true if the pattern match 
	 }
}
function check_address() //this function is check state validation 
{
	var address=document.form.address.value;
	 if (address == "")
	 {
		document.getElementById("addressimg").style.display="initial";
		document.getElementById("addressimg").src="images/wrong.png";
		return false;//return false if the pattern does not match 
	 }
	 else
	 {
		document.getElementById("addressimg").style.display="initial";
		document.getElementById("addressimg").src="images/right.png";
		return true;//return true if the pattern match 
	 }
}
function check_agree()
{
if(document.getElementById('agree').checked)//this check checkbox is checked or not
			 { 
			 return true; //return true if checkbox is checked
			 }
			  else 
			  {
			   alert('Please indicate that you have read and agree to the Terms and Conditions and Privacy Policy');
			    return false; ////return false if checkbox is unchecked
				}
}