function read() //this function call at the page loading time
{
var queryString = decodeURIComponent(window.location.search); //this statement set uri component into the querystring variable
queryString = queryString.substring(6); //removing the first 6 charactor of the line. like ?name=
var queries = queryString.split("&"); //break the line when read &
 /*document.write(queries[0] + "<br>");
document.write(queries[1] + "<br>");
document.write(queries[2] + "<br>");
document.write(queries[3] + "<br>");
document.write(queries[4] + "<br>");
document.write(queries[5] + "<br>");
document.write(queries[6] + "<br>");
document.write(queries[7] + "<br>");*/
 document.getElementById("name").value=queries[0]; //print the name into name textbox.
 document.getElementById("mobile").value=queries[1].substring(7); //print the number into number text box but firstly remove starting 7 charactor like number=
 document.getElementById("state").value=queries[2].substring(6);
 document.getElementById("district").value=queries[3].substring(9);
 document.getElementById("mondal").value=queries[4].substring(7);
 document.getElementById("village").value=queries[5].substring(8);
 document.getElementById("address").value=queries[6].substring(8);
 }
 // alert mobile number
function AlertNumber() {
   var number=document.myform.mobile.value;
   alert(number);
}
// functionality of name textbox editable and change the color of text
function NameChange() {
    document.getElementById("name").removeAttribute("readonly"); 
	document.myform.name.style.color="red";
}
// functionality of name textbox editable and change the color of text
function NumberChange() {
    document.getElementById("mobile").removeAttribute("readonly"); 
	document.myform.mobile.style.color="red";
		document.myform.verify.style.display = "block";
}
// functionality of address textbox editable and change the color of text
function AddressChange() {
    document.getElementById("address").removeAttribute("readonly"); 
	document.myform.address.style.color="red";
}
// functionality of textbox(name,mobile,address) readonly after update and change the color of text also hide the verify button
function  updateData() {
 document.getElementById("name").setAttribute("readonly", ""); //add attribute readonly
 document.getElementById("mobile").setAttribute("readonly", "");
 document.getElementById("address").setAttribute("readonly", "");
 	document.myform.verify.style.display = "none";  //hide verify button
document.myform.address.style.color="black"; 
 document.myform.mobile.style.color="black"; //change the color after click on  update button
 document.myform.name.style.color="black"; 
}
/* image upload using input type file*/
//<![CDATA[ 
window.addEvent('load', function() {
var imageLoader = document.getElementById('imageLoader');
    imageLoader.addEventListener('change', handleImage, false);
var c = document.getElementById('upload');
var ctx = c.getContext('2d');
function handleImage(e){
    var reader = new FileReader();
    reader.onload = function(event){
        var img = new Image();
        img.onload = function(){
            c.width = img.width;
            c.height = img.height;
            ctx.drawImage(img,0,0);
        }
        img.src = event.target.result;
    }
    reader.readAsDataURL(e.target.files[0]);     
}
});//]]>  