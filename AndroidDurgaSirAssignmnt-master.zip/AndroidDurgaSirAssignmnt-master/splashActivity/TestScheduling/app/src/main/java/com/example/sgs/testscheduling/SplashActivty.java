package com.example.sgs.testscheduling;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SplashActivty extends AppCompatActivity {

    Context context;

    private Handler handler;
    Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        context = SplashActivty.this;
        handler = new Handler();



        runnable = new Runnable() {
            @Override
            public void run() {
                context.startActivity(new Intent(context, MainActivity.class));
                finish();
            }
        };

        handler.postDelayed(runnable, 5000);
    }

    @Override
    public void onBackPressed() {
        handler.removeCallbacks(runnable);
        super.onBackPressed();
    }
}
