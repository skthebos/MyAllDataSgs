import java.util.*;
class Swap
	{
	public static void main(String []args)
	{
		
		int a,b,c;
	
		a=Integer.parseInt(args[0]);
		b=Integer.parseInt(args[1]);
		System.out.println(a+" "+b);

		c=a;
		a=b;
		b=c;

		System.out.println(a+" "+b);
	
	}


}
