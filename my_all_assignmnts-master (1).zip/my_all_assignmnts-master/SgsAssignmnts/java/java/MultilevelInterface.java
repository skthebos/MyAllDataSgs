class MultilevelInterface
	{
	public static void main(String []args)
		{
		Main obj=new Main();

		obj.methodA();
		obj.methodB();
		}

	}
interface A
{
	public void methodA();
}


interface B extends A
{
	public void methodB();
}

class Main implements B
{
	
	public void methodA()
	{		System.out.println("multilevel Interface");
		System.out.println("method A of Interface A");
		
	}
	
	public void methodB()
	{
		System.out.println("method B of Interface B");
		
	}
}

