class EvenOdd
	{
	public static void main(String []args)
	{


	int a=Integer.parseInt(args[0]);
	int x,y;
	x=4;
	y=1;

		System.out.println(x&y);
			
			if( (a&1) == 0)
			{
			System.out.println("even number");
			}
			else
			System.out.println("odd number");
			
	



	}
	}
