class multipleInter {

	public static void main(String []args)
	{
		
	
	Result r=new Result();
	r.methodA();
	r.methodB();
	
	}
	
	
}
interface ABC
{
public void methodA();	
}

interface XYZ 
{
	public void methodB();
	
}

class Result implements ABC,XYZ
{
	
public void methodA()
{
	System.out.println("multiple Interface");

	System.out.println(" method A of Interface A");
	

	
}
	
public void methodB()
{

	System.out.println("method B of Interface B");
	

	
}

}
