function onsubmit_check()//this function check validations on the name,number,textarea,checkbox etc.
{		 
		//alert("hello");
		var name = document.form.name.value; //access the value of name textbox and then assign to the  variable name.
		var mobile = document.form.mobile.value; //access the value of mobile number textbox and then assign to the  variable mobile.
		var agree = document.form.agree.value; //access the value of agree checkbox it is checked or not and then assign to the variable agree.
		var address=document.form.address.value;
		if(name=="") //if name is blank then pointer enter in this if statement and return false.
		{
		alert("Please Enter Your Name");
		document.form.name.select();
		return false;  // if we return false then this form will not submit this condition is valid if name is blank.
		}
		if(!isNaN(name)) //this check enter value is string or not
			{
			alert("Please Enter Only Characters");
			document.form.name.select();
			return false; //if user enter any numbers in the text feild then this return false.
			}			
			if ((name.length < 1) || (name.length > 10))//this check the length of the name.
				{
				alert("Your Character must be 1 to 10 Character");
				document.form.name.select();
				return false; //if name is less then 1 and greater then 10.then it return false.
				}
		  if(mobile.length<1) //this statement checks the length of mobile number
	   {
	     alert("your mobile number is  invalid");
	    document.form.mobile.select();
	     return false;//it return false if the number length is less the 1
	   }
				if(isNaN(mobile)) //this check enter value is digits or not
			{
			alert("Please Enter Only numbers");
			document.form.mobile.select();
			return false; //return false if the user enter string in mobile number textbox 
			}
	   if ((mobile.length < 9) || (mobile.length > 11)) //check the length of the mobile number
				{
				alert("Your Mobile number must be 10 Digits");
				document.form.mobile.select();
				return false; //return false if the length is 9 or 11
				}
				  if(address.length<1) //this statement checks the length of address
	   {
	     alert("your address is invalid");
	    document.form.address.select();
	     return false;//it return false if the address length is less the 1
	   }
	   if ((address.length < 6) || (address.length > 30)) //check the length of the address number
				{
				alert("Your address must be 6 to 30 Character");
				document.form.address.select();
				return false; //return false if the length is 5 or 31
				}
			if(document.getElementById('agree').checked)//this check checkbox is checked or not
			 { 
			 return true; //return true if checkbox is checked
			 }
			  else 
			  {
			   alert('Please indicate that you have read and agree to the Terms and Conditions and Privacy Policy');
			    return false; ////return false if checkbox is unchecked
				}
	}
   